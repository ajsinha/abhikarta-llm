# Workflow Management Module - Quick Start Guide

**Get up and running in 5 minutes!**

## Step 1: Install Database Schema (2 minutes)

```bash
# For SQLite (recommended for testing)
cd workflow_management/db_schemas
sqlite3 /path/to/abhikarta.db < sqlite_schema.sql
```

## Step 2: Copy Module (1 minute)

```bash
# Copy the entire workflow_management directory
cp -r workflow_management /path/to/abhikarta/
```

## Step 3: Register Routes (1 minute)

Edit `/path/to/abhikarta/abhikarta_llm_web.py`:

```python
# Add import at top
from workflow_management.workflow_routes import WorkflowRoutes

# Add to route registration list (in _register_routes method)
for rt in [..., WorkflowRoutes]:  # Add WorkflowRoutes to the list
    # ... existing code ...
```

## Step 4: Start and Test (1 minute)

```bash
# Start Abhikarta
cd /path/to/abhikarta
python main.py

# Open browser
http://localhost:5000/workflow/dashboard
```

## Create Your First Workflow

1. Click **"Create Workflow"**
2. Enter name: "Hello World"
3. Click **"Load Sample Template"**
4. Click **"Create Workflow"**
5. Click **Play** button to execute
6. Watch it run in real-time!

## What's Next?

- Read the full [README.md](README.md) for comprehensive documentation
- Follow the [INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md) for production setup
- Explore the sample workflow definitions in the UI
- Review the database schema files for data model understanding

## Quick Tips

✓ Use the dashboard to monitor all executions  
✓ Check the tasks page for pending approvals  
✓ View execution logs for debugging  
✓ Tags help organize workflows  
✓ Status "active" makes workflows production-ready  

## Need Help?

- Check the full README for detailed documentation
- Review the INSTALLATION_GUIDE for troubleshooting
- Email: ajsinha@gmail.com

---

**Happy Workflow Orchestrating!** 🚀
