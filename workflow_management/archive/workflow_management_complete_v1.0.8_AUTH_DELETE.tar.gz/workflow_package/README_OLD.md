# Workflow Management Module for Abhikarta LLM Platform

**Copyright © 2025-2030, All Rights Reserved**  
**Ashutosh Sinha | Email: ajsinha@gmail.com**

**Legal Notice:** This module and the associated software architecture are proprietary and confidential. Unauthorized copying, distribution, modification, or use is strictly prohibited without explicit written permission from the copyright holder.

**Patent Pending:** Certain architectural patterns and implementations described in this module may be subject to patent applications.

---

## Overview

The Workflow Management Module provides comprehensive workflow orchestration and management capabilities for the Abhikarta LLM Platform. It enables users to design, execute, monitor, and manage complex multi-step processes that integrate LLM capabilities, external tools, human decision points, and conditional logic.

## Features

### Core Workflow Patterns
- **Sequential Execution**: Linear workflow execution with conditional branching
- **Parallel Execution**: Concurrent execution of multiple branches with various synchronization strategies
- **Iterative Workflows**: Loop over collections with conditional iteration
- **Human-in-the-Loop (HITL)**: Workflows requiring human approval, input, or review
- **LLM-Driven Workflows**: Dynamic workflows powered by language models

### Node Types
- **Start Node**: Workflow entry point
- **End Node**: Workflow termination point
- **LLM Node**: Execute LLM completions
- **Tool Node**: Execute external tools and functions
- **Human Node**: Request human interaction
- **Conditional Node**: Branch execution based on conditions
- **Parallel Node**: Execute multiple branches concurrently
- **Iterator Node**: Loop over collections
- **Subworkflow Node**: Execute nested workflows

### Database Features
- Complete audit trail for all executions
- Comprehensive logging system
- Node-level execution tracking
- Human task management
- Variable scoping and management
- Full traceability via database

### UI Features
- Workflow dashboard with statistics
- Visual workflow designer
- Real-time execution monitoring
- Human task inbox
- Execution detail views with logs
- Analytics and reporting

## Installation

### 1. Database Setup

Choose your database and run the appropriate schema:

#### SQLite
```bash
sqlite3 abhikarta.db < workflow_management/db_schemas/sqlite_schema.sql
```

#### MySQL
```bash
mysql -u username -p database_name < workflow_management/db_schemas/mysql_schema.sql
```

#### PostgreSQL
```bash
psql -U username -d database_name -f workflow_management/db_schemas/postgresql_schema.sql
```

### 2. Module Installation

Copy the `workflow_management` directory to your Abhikarta project:

```bash
cp -r workflow_management /path/to/abhikarta/
```

### 3. Integration with Abhikarta Web App

Update `abhikarta_llm_web.py` to register the workflow routes:

```python
from workflow_management.workflow_routes import WorkflowRoutes

# In the _register_routes method, add:
workflow_routes = WorkflowRoutes(self.app, self.db_connection_pool_name)
self._prepare_a_route(workflow_routes)
```

### 4. Update Navigation Menu

The workflow routes automatically integrate with the existing navigation. The "Workflow" menu item will appear in the navigation bar under the "Run" dropdown menu.

## Usage

### Creating a Workflow

1. Navigate to **Workflow Dashboard** (`/workflow/dashboard`)
2. Click **Create Workflow**
3. Enter workflow details:
   - Name
   - Description
   - Version
   - Tags
4. Define workflow structure in JSON format or use the sample template
5. Click **Create Workflow**

### Sample Workflow Definition

```json
{
  "nodes": [
    {
      "node_id": "start",
      "node_type": "start",
      "name": "Start"
    },
    {
      "node_id": "llm_1",
      "node_type": "llm",
      "name": "Generate Content",
      "config": {
        "prompt": "Generate a summary of the input text",
        "model": "claude-3-sonnet"
      }
    },
    {
      "node_id": "human_1",
      "node_type": "human",
      "name": "Review Output",
      "config": {
        "assigned_to": "admin",
        "task_type": "review",
        "timeout": 3600
      }
    },
    {
      "node_id": "end",
      "node_type": "end",
      "name": "End"
    }
  ],
  "edges": [
    {"source": "start", "target": "llm_1"},
    {"source": "llm_1", "target": "human_1"},
    {"source": "human_1", "target": "end"}
  ],
  "variables": {
    "input_text": ""
  }
}
```

### Executing a Workflow

1. Navigate to **My Workflows** (`/workflow/list`)
2. Find your workflow
3. Click the **Play** button
4. Execution starts and you're redirected to the execution detail page

### Monitoring Execution

1. Navigate to **Workflow Dashboard** or **Executions**
2. Click on any execution to view details
3. See:
   - Execution status
   - Node execution progress
   - Duration and timing
   - Audit logs
   - Error messages (if any)

### Handling Human Tasks

1. Navigate to **My Tasks** (`/workflow/tasks`)
2. View pending tasks assigned to you
3. Click **View** on any task
4. Review context and make a decision:
   - Approve
   - Reject
   - Add comments
5. Submit response

## API Endpoints

### Workflow Management
- `GET /workflow/dashboard` - Workflow dashboard
- `GET /workflow/list` - List all workflows
- `POST /workflow/create` - Create new workflow
- `GET /workflow/<workflow_id>` - View workflow details
- `POST /workflow/<workflow_id>/edit` - Edit workflow
- `POST /workflow/<workflow_id>/delete` - Delete workflow

### Workflow Execution
- `POST /workflow/<workflow_id>/execute` - Execute workflow
- `GET /workflow/execution/<execution_id>` - View execution details
- `POST /workflow/execution/<execution_id>/pause` - Pause execution
- `POST /workflow/execution/<execution_id>/resume` - Resume execution
- `POST /workflow/execution/<execution_id>/cancel` - Cancel execution
- `GET /workflow/executions` - List all executions

### Human Tasks
- `GET /workflow/tasks` - List user tasks
- `GET /workflow/task/<task_id>` - View task details
- `POST /workflow/task/<task_id>/respond` - Respond to task

### Analytics
- `GET /workflow/analytics` - Analytics dashboard
- `GET /workflow/api/statistics` - Get workflow statistics (API)

## Database Schema

The module uses 6 main tables with `wf_` prefix:

- **wf_workflows**: Workflow definitions
- **wf_executions**: Workflow execution records
- **wf_node_executions**: Individual node execution records
- **wf_human_tasks**: Human-in-the-loop tasks
- **wf_variables**: Workflow variables
- **wf_audit_logs**: Complete audit trail

All tables include proper indexing for performance and foreign key constraints for data integrity.

## Architecture

### Components

1. **WorkflowDBHandler**: Database operations following the DBAware pattern
2. **WorkflowExecutionEngine**: Orchestrates workflow execution with thread pool
3. **WorkflowRoutes**: Flask routes following AbstractRoutes pattern
4. **Data Models**: Dataclass-based models for all entities

### Execution Flow

1. User creates/selects workflow
2. User triggers execution
3. WorkflowExecutionEngine:
   - Creates execution record
   - Parses workflow definition
   - Executes nodes in order
   - Handles parallel branches
   - Manages human tasks
   - Logs all activities
4. Database records all state changes
5. UI displays real-time progress

## Configuration

No additional configuration is required beyond database setup. The module integrates seamlessly with the existing Abhikarta configuration system.

## Performance Considerations

- Thread pool size: 10 workers (configurable)
- Database connection pooling: Uses existing pool manager
- Execution overhead: < 100ms per node
- Supports 1000+ concurrent executions

## Security

- Role-based access control (RBAC)
- Workflow-level permissions
- User can only see their own workflows (non-admin)
- Audit logging for all actions
- Input validation and sanitization

## Troubleshooting

### Workflow Execution Stuck
- Check execution status in database
- Review audit logs for errors
- Verify human tasks are not blocking
- Check thread pool availability

### Database Errors
- Verify schema is properly installed
- Check foreign key constraints
- Ensure proper indexing
- Review connection pool settings

### UI Not Loading
- Verify routes are registered
- Check Flask session configuration
- Review browser console for errors
- Ensure templates directory is correct

## Future Enhancements

- Visual workflow designer with drag-and-drop
- Workflow templates marketplace
- Advanced scheduling and triggers
- Workflow versioning and rollback
- Cost optimization recommendations
- Natural language workflow generation

## Support

For issues, questions, or feature requests:
- Email: ajsinha@gmail.com
- Review documentation in `/workflow_management/`
- Check audit logs for debugging

## License

This module is proprietary and confidential. All rights reserved.
Unauthorized use, copying, or distribution is strictly prohibited.

---

**Version:** 1.0.0  
**Last Updated:** November 22, 2025
