#!/usr/bin/env python3
"""
Integration Test for Complete Workflow System

Copyright © 2025-2030, All Rights Reserved
Ashutosh Sinha | Email: ajsinha@gmail.com

This script performs end-to-end integration testing without database.
"""

import sys
import json
import time
from datetime import datetime

from workflow_management.example_tools import (
    TextAnalysisTool,
    DataTransformTool,
    MathCalculatorTool,
    RandomNumberTool,
    get_tool
)
from workflow_management.workflow_builders import (
    WorkflowBuilder,
    WorkflowNode,
    WorkflowEdge
)


def print_separator(char="=", length=80):
    """Print a separator line"""
    print(char * length)


def print_header(title):
    """Print a section header"""
    print_separator()
    print(f"  {title}")
    print_separator()


class SimpleWorkflowExecutor:
    """
    Simplified workflow executor for testing without database.
    Executes workflows in-memory for demonstration purposes.
    """
    
    def __init__(self):
        self.execution_log = []
    
    def execute_workflow(self, workflow_def: dict) -> dict:
        """Execute a workflow definition"""
        print(f"\nExecuting Workflow: {workflow_def['name']}")
        print(f"Description: {workflow_def['description']}")
        print_separator("-")
        
        workflow = workflow_def['workflow']
        nodes = {n['node_id']: n for n in workflow['nodes']}
        edges = workflow['edges']
        context = {
            'variables': workflow.get('variables', {}),
            'node_outputs': {}
        }
        
        # Find start node
        start_node = next((n for n in workflow['nodes'] if n['node_type'] == 'start'), None)
        if not start_node:
            return {'success': False, 'error': 'No start node found'}
        
        # Execute from start
        result = self._execute_from_node(start_node['node_id'], nodes, edges, context)
        
        print_separator("-")
        print(f"✓ Workflow Execution Complete\n")
        
        return {
            'success': True,
            'context': context,
            'result': result,
            'execution_log': self.execution_log
        }
    
    def _execute_from_node(self, node_id: str, nodes: dict, edges: list, context: dict):
        """Execute starting from a given node"""
        if node_id not in nodes:
            print(f"  ✗ Node not found: {node_id}")
            return None
        
        node = nodes[node_id]
        node_type = node['node_type']
        
        # Skip end nodes
        if node_type == 'end':
            print(f"  → Reached end node: {node['name']}")
            return {'status': 'completed', 'node': node['name']}
        
        # Skip start nodes
        if node_type == 'start':
            print(f"  ► Starting workflow from: {node['name']}")
            output = {'status': 'started'}
        else:
            # Execute current node
            print(f"  ⚙ Executing: [{node_id}] {node['name']} ({node_type})")
            output = self._execute_node(node, context)
            
            # Store output
            context['node_outputs'][node_id] = output
            self.execution_log.append({
                'node_id': node_id,
                'node_name': node['name'],
                'node_type': node_type,
                'output': output,
                'timestamp': datetime.now().isoformat()
            })
            
            # Print output
            if output.get('status') == 'completed':
                result = output.get('result', {})
                if isinstance(result, dict) and result:
                    print(f"    ✓ Result: {json.dumps(result, indent=6)}")
            elif output.get('status') == 'failed':
                print(f"    ✗ Failed: {output.get('error')}")
        
        # Find next nodes
        next_edges = [e for e in edges if e.get('source') == node_id]
        
        if not next_edges:
            return output
        
        # Handle parallel execution
        if node_type == 'parallel':
            print(f"    → Parallel execution: {len(next_edges)} branches")
            for edge in next_edges:
                self._execute_from_node(edge.get('target'), nodes, edges, context)
        else:
            # Sequential execution
            for edge in next_edges:
                self._execute_from_node(edge.get('target'), nodes, edges, context)
        
        return output
    
    def _execute_node(self, node: dict, context: dict) -> dict:
        """Execute a single node"""
        node_type = node['node_type']
        
        try:
            if node_type == 'tool':
                return self._execute_tool_node(node, context)
            elif node_type == 'parallel':
                return {'status': 'parallel_split', 'message': 'Parallel execution starting'}
            elif node_type == 'conditional':
                return self._execute_conditional_node(node, context)
            else:
                return {'status': 'skipped', 'message': f'Node type {node_type} not implemented'}
        except Exception as e:
            return {
                'status': 'failed',
                'error': str(e),
                'error_type': type(e).__name__
            }
    
    def _execute_tool_node(self, node: dict, context: dict) -> dict:
        """Execute a tool node"""
        config = node.get('config', {})
        tool_name = config.get('tool_name', '')
        parameters = config.get('parameters', {})
        
        # Resolve variables in parameters
        resolved_params = {}
        for key, value in parameters.items():
            if isinstance(value, str) and '{{' in value:
                var_name = value.replace('{{', '').replace('}}', '').strip()
                resolved_value = context.get('variables', {}).get(var_name, value)
                resolved_params[key] = resolved_value
            else:
                resolved_params[key] = value
        
        # Get and execute tool
        tool = get_tool(tool_name)
        result = tool._execute_with_tracking(**resolved_params)
        
        # Update context with result
        if result.success and isinstance(result.data, dict):
            for key, value in result.data.items():
                context['variables'][key] = value
        
        if result.success:
            return {
                'status': 'completed',
                'tool': tool_name,
                'result': result.data,
                'execution_time': result.execution_time
            }
        else:
            return {
                'status': 'failed',
                'tool': tool_name,
                'error': result.error,
                'error_type': result.error_type
            }
    
    def _execute_conditional_node(self, node: dict, context: dict) -> dict:
        """Execute conditional node"""
        config = node.get('config', {})
        condition = config.get('condition', 'true')
        
        # Simple condition evaluation
        try:
            result = eval(condition, {}, context.get('variables', {}))
            return {
                'status': 'completed',
                'condition': condition,
                'result': result
            }
        except Exception as e:
            return {
                'status': 'failed',
                'error': str(e)
            }


def test_simple_sequential_workflow():
    """Test a simple sequential workflow"""
    print_header("Test 1: Simple Sequential Workflow")
    
    builder = WorkflowBuilder(
        name="Simple Text Processing",
        description="Text analysis then transformation",
        version="1.0.0"
    )
    
    # Build simple workflow
    builder.add_node(WorkflowNode(
        node_id="start",
        node_type="start",
        name="Start"
    ))
    
    builder.add_node(WorkflowNode(
        node_id="analyze",
        node_type="tool",
        name="Analyze Text",
        config={
            "tool_name": "text_analysis",
            "parameters": {"text": "{{input_text}}"}
        }
    ))
    
    builder.add_node(WorkflowNode(
        node_id="transform",
        node_type="tool",
        name="Transform to Uppercase",
        config={
            "tool_name": "data_transform",
            "parameters": {
                "input_data": "{{input_text}}",
                "operation": "uppercase"
            }
        }
    ))
    
    builder.add_node(WorkflowNode(
        node_id="end",
        node_type="end",
        name="End"
    ))
    
    builder.add_edge(WorkflowEdge("start", "analyze"))
    builder.add_edge(WorkflowEdge("analyze", "transform"))
    builder.add_edge(WorkflowEdge("transform", "end"))
    
    builder.set_variable("input_text", "Hello World from Abhikarta!")
    
    # Execute
    executor = SimpleWorkflowExecutor()
    result = executor.execute_workflow(builder.build())
    
    print(f"Success: {result['success']}")
    print()
    
    return result['success']


def test_parallel_workflow():
    """Test parallel execution workflow"""
    print_header("Test 2: Parallel Execution Workflow")
    
    builder = WorkflowBuilder(
        name="Parallel Processing",
        description="Multiple tools execute in parallel",
        version="1.0.0"
    )
    
    builder.add_node(WorkflowNode(node_id="start", node_type="start", name="Start"))
    
    builder.add_node(WorkflowNode(
        node_id="parallel_start",
        node_type="parallel",
        name="Start Parallel"
    ))
    
    builder.add_node(WorkflowNode(
        node_id="branch1",
        node_type="tool",
        name="Branch 1: Text Analysis",
        config={
            "tool_name": "text_analysis",
            "parameters": {"text": "Branch 1 executing"}
        }
    ))
    
    builder.add_node(WorkflowNode(
        node_id="branch2",
        node_type="tool",
        name="Branch 2: Random Numbers",
        config={
            "tool_name": "random_number",
            "parameters": {"min_value": 1, "max_value": 10, "count": 3}
        }
    ))
    
    builder.add_node(WorkflowNode(
        node_id="branch3",
        node_type="tool",
        name="Branch 3: Math Calculation",
        config={
            "tool_name": "math_calculator",
            "parameters": {"operation": "add", "operand1": 10, "operand2": 20}
        }
    ))
    
    builder.add_node(WorkflowNode(node_id="end", node_type="end", name="End"))
    
    builder.add_edge(WorkflowEdge("start", "parallel_start"))
    builder.add_edge(WorkflowEdge("parallel_start", "branch1", priority=1))
    builder.add_edge(WorkflowEdge("parallel_start", "branch2", priority=2))
    builder.add_edge(WorkflowEdge("parallel_start", "branch3", priority=3))
    builder.add_edge(WorkflowEdge("branch1", "end"))
    builder.add_edge(WorkflowEdge("branch2", "end"))
    builder.add_edge(WorkflowEdge("branch3", "end"))
    
    # Execute
    executor = SimpleWorkflowExecutor()
    result = executor.execute_workflow(builder.build())
    
    print(f"Success: {result['success']}")
    print()
    
    return result['success']


def test_calculation_workflow():
    """Test mathematical calculation workflow"""
    print_header("Test 3: Mathematical Calculation Workflow")
    
    builder = WorkflowBuilder(
        name="Math Processing",
        description="Perform multiple calculations",
        version="1.0.0"
    )
    
    builder.add_node(WorkflowNode(node_id="start", node_type="start", name="Start"))
    
    builder.add_node(WorkflowNode(
        node_id="calc1",
        node_type="tool",
        name="Addition",
        config={
            "tool_name": "math_calculator",
            "parameters": {"operation": "add", "operand1": 100, "operand2": 50}
        }
    ))
    
    builder.add_node(WorkflowNode(
        node_id="calc2",
        node_type="tool",
        name="Multiplication",
        config={
            "tool_name": "math_calculator",
            "parameters": {"operation": "multiply", "operand1": 5, "operand2": 10}
        }
    ))
    
    builder.add_node(WorkflowNode(
        node_id="calc3",
        node_type="tool",
        name="Power",
        config={
            "tool_name": "math_calculator",
            "parameters": {"operation": "power", "operand1": 2, "operand2": 8}
        }
    ))
    
    builder.add_node(WorkflowNode(node_id="end", node_type="end", name="End"))
    
    builder.add_edge(WorkflowEdge("start", "calc1"))
    builder.add_edge(WorkflowEdge("calc1", "calc2"))
    builder.add_edge(WorkflowEdge("calc2", "calc3"))
    builder.add_edge(WorkflowEdge("calc3", "end"))
    
    # Execute
    executor = SimpleWorkflowExecutor()
    result = executor.execute_workflow(builder.build())
    
    print(f"Success: {result['success']}")
    print()
    
    return result['success']


def test_data_validation_workflow():
    """Test data validation workflow"""
    print_header("Test 4: Data Validation Workflow")
    
    builder = WorkflowBuilder(
        name="Data Validation",
        description="Generate and validate data",
        version="1.0.0"
    )
    
    builder.add_node(WorkflowNode(node_id="start", node_type="start", name="Start"))
    
    builder.add_node(WorkflowNode(
        node_id="generate",
        node_type="tool",
        name="Generate Random Number",
        config={
            "tool_name": "random_number",
            "parameters": {"min_value": 1, "max_value": 200, "count": 1}
        }
    ))
    
    builder.add_node(WorkflowNode(
        node_id="validate",
        node_type="tool",
        name="Validate Number",
        config={
            "tool_name": "data_validator",
            "parameters": {
                "value": 75,
                "min_threshold": 0,
                "max_threshold": 100
            }
        }
    ))
    
    builder.add_node(WorkflowNode(node_id="end", node_type="end", name="End"))
    
    builder.add_edge(WorkflowEdge("start", "generate"))
    builder.add_edge(WorkflowEdge("generate", "validate"))
    builder.add_edge(WorkflowEdge("validate", "end"))
    
    # Execute
    executor = SimpleWorkflowExecutor()
    result = executor.execute_workflow(builder.build())
    
    print(f"Success: {result['success']}")
    print()
    
    return result['success']


def main():
    """Main integration test"""
    print("\n")
    print("=" * 80)
    print("  ABHIKARTA WORKFLOW SYSTEM - INTEGRATION TEST")
    print("=" * 80)
    print("\n")
    
    print("This test demonstrates end-to-end workflow execution")
    print("with actual tool integration (no database required).\n")
    
    results = []
    
    try:
        # Run all tests
        results.append(("Simple Sequential", test_simple_sequential_workflow()))
        results.append(("Parallel Execution", test_parallel_workflow()))
        results.append(("Math Calculations", test_calculation_workflow()))
        results.append(("Data Validation", test_data_validation_workflow()))
        
        # Summary
        print_separator("=")
        print("  TEST SUMMARY")
        print_separator("=")
        
        total = len(results)
        passed = sum(1 for _, success in results if success)
        
        for test_name, success in results:
            status = "✓ PASS" if success else "✗ FAIL"
            print(f"  {status}: {test_name}")
        
        print()
        print(f"  Total: {total}")
        print(f"  Passed: {passed}")
        print(f"  Failed: {total - passed}")
        print_separator("=")
        
        if passed == total:
            print("  ✓ ALL INTEGRATION TESTS PASSED!")
            print_separator("=")
            return 0
        else:
            print("  ⚠ SOME TESTS FAILED")
            print_separator("=")
            return 1
    
    except Exception as e:
        print(f"\n✗ ERROR: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
