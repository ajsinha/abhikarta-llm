# Workflow Examples Documentation

Generated: 2025-11-22 17:11:57

## Sequential Workflow

**Description:** Processes text through a sequence of transformations

**Version:** 1.0.0

**Statistics:**
- Nodes: 5
- Edges: 4
- Variables: 1

**Nodes:**
- `start`: Start (start)
- `analyze_text`: Analyze Text (tool)
- `transform_text`: Transform to Uppercase (tool)
- `validate_length`: Validate Word Count (tool)
- `end`: End (end)

**Flow:**
```
start -> analyze_text
analyze_text -> transform_text
transform_text -> validate_length
validate_length -> end
```

---

## Parallel Workflow

**Description:** Processes data in parallel branches

**Version:** 1.0.0

**Statistics:**
- Nodes: 8
- Edges: 9
- Variables: 1

**Nodes:**
- `start`: Start (start)
- `parallel_split`: Split into Parallel Branches (parallel)
- `branch1_analysis`: Text Analysis Branch (tool)
- `branch2_transform`: Transform Branch (tool)
- `branch3_random`: Random Number Generation (tool)
- `parallel_join`: Join Parallel Results (parallel)
- `aggregate`: Aggregate Results (tool)
- `end`: End (end)

**Flow:**
```
start -> parallel_split
parallel_split -> branch1_analysis
parallel_split -> branch2_transform
parallel_split -> branch3_random
branch1_analysis -> parallel_join
branch2_transform -> parallel_join
branch3_random -> parallel_join
parallel_join -> aggregate
aggregate -> end
```

---

## HITL Workflow

**Description:** Requires human review and approval before proceeding

**Version:** 1.0.0

**Statistics:**
- Nodes: 9
- Edges: 8
- Variables: 0

**Nodes:**
- `start`: Start (start)
- `generate_data`: Generate Random Data (tool)
- `calculate_sum`: Calculate Statistics (tool)
- `human_approval`: Request Human Approval (human)
- `check_approval`: Check Approval Status (conditional)
- `approved_action`: Process Approved Data (tool)
- `rejected_action`: Handle Rejection (tool)
- `end_approved`: End (Approved Path) (end)
- `end_rejected`: End (Rejected Path) (end)

**Flow:**
```
start -> generate_data
generate_data -> calculate_sum
calculate_sum -> human_approval
human_approval -> check_approval
check_approval -> approved_action
check_approval -> rejected_action
approved_action -> end_approved
rejected_action -> end_rejected
```

---

## Complex Workflow

**Description:** Demonstrates all workflow patterns in a single workflow

**Version:** 1.0.0

**Statistics:**
- Nodes: 9
- Edges: 9
- Variables: 1

**Nodes:**
- `start`: Start (start)
- `initial_analysis`: Initial Data Analysis (tool)
- `parallel_start`: Start Parallel Processing (parallel)
- `parallel_branch1`: Parallel Branch 1 (tool)
- `parallel_branch2`: Parallel Branch 2 (tool)
- `parallel_end`: End Parallel Processing (parallel)
- `human_review`: Quality Review (human)
- `final_calculation`: Final Calculation (tool)
- `end`: End (end)

**Flow:**
```
start -> initial_analysis
initial_analysis -> parallel_start
parallel_start -> parallel_branch1
parallel_start -> parallel_branch2
parallel_branch1 -> parallel_end
parallel_branch2 -> parallel_end
parallel_end -> human_review
human_review -> final_calculation
final_calculation -> end
```

---

