#!/usr/bin/env python3
"""
Test Script for Workflow Execution

Copyright © 2025-2030, All Rights Reserved
Ashutosh Sinha | Email: ajsinha@gmail.com

This script tests workflow execution with various patterns.
"""

import sys
import json
import os
import time
from datetime import datetime

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from workflow_management.workflow_builders import (
    create_sequential_workflow,
    create_parallel_workflow,
    create_hitl_workflow,
    create_complex_workflow
)


def print_separator(char="=", length=80):
    """Print a separator line"""
    print(char * length)


def print_header(title):
    """Print a section header"""
    print_separator()
    print(f"  {title}")
    print_separator()


def print_workflow_summary(workflow_def):
    """Print workflow summary"""
    print(f"Name: {workflow_def['name']}")
    print(f"Description: {workflow_def['description']}")
    print(f"Version: {workflow_def['version']}")
    print(f"Nodes: {len(workflow_def['workflow']['nodes'])}")
    print(f"Edges: {len(workflow_def['workflow']['edges'])}")
    print(f"Variables: {len(workflow_def['workflow']['variables'])}")
    print()


def print_node_list(nodes):
    """Print list of nodes"""
    print("Nodes:")
    for node in nodes:
        print(f"  [{node['node_id']}] {node['name']} ({node['node_type']})")
    print()


def print_edge_list(edges):
    """Print list of edges"""
    print("Edges:")
    for edge in edges:
        condition = f" IF {edge.get('condition')}" if edge.get('condition') else ""
        print(f"  {edge['source']} -> {edge['target']}{condition}")
    print()


def test_sequential_workflow():
    """Test sequential workflow"""
    print_header("Sequential Workflow Test")
    
    builder = create_sequential_workflow()
    workflow_def = builder.build()
    
    print_workflow_summary(workflow_def)
    print_node_list(workflow_def['workflow']['nodes'])
    print_edge_list(workflow_def['workflow']['edges'])
    
    print("Variables:")
    for key, value in workflow_def['workflow']['variables'].items():
        print(f"  {key}: {value}")
    print()
    
    # Save to file
    filename = "test_sequential_workflow.json"
    builder.save_to_file(filename)
    print(f"✓ Workflow definition saved to: {filename}")
    print()
    
    return workflow_def


def test_parallel_workflow():
    """Test parallel workflow"""
    print_header("Parallel Workflow Test")
    
    builder = create_parallel_workflow()
    workflow_def = builder.build()
    
    print_workflow_summary(workflow_def)
    print_node_list(workflow_def['workflow']['nodes'])
    print_edge_list(workflow_def['workflow']['edges'])
    
    # Save to file
    filename = "test_parallel_workflow.json"
    builder.save_to_file(filename)
    print(f"✓ Workflow definition saved to: {filename}")
    print()
    
    return workflow_def


def test_hitl_workflow():
    """Test HITL workflow"""
    print_header("Human-in-the-Loop Workflow Test")
    
    builder = create_hitl_workflow()
    workflow_def = builder.build()
    
    print_workflow_summary(workflow_def)
    print_node_list(workflow_def['workflow']['nodes'])
    print_edge_list(workflow_def['workflow']['edges'])
    
    # Highlight human nodes
    print("Human Nodes:")
    for node in workflow_def['workflow']['nodes']:
        if node['node_type'] == 'human':
            print(f"  • {node['name']}")
            print(f"    Assigned to: {node['config'].get('assigned_to')}")
            print(f"    Task type: {node['config'].get('task_type')}")
            print(f"    Timeout: {node['config'].get('timeout')}s")
    print()
    
    # Save to file
    filename = "test_hitl_workflow.json"
    builder.save_to_file(filename)
    print(f"✓ Workflow definition saved to: {filename}")
    print()
    
    return workflow_def


def test_complex_workflow():
    """Test complex workflow"""
    print_header("Complex Multi-Pattern Workflow Test")
    
    builder = create_complex_workflow()
    workflow_def = builder.build()
    
    print_workflow_summary(workflow_def)
    
    # Count node types
    node_types = {}
    for node in workflow_def['workflow']['nodes']:
        node_type = node['node_type']
        node_types[node_type] = node_types.get(node_type, 0) + 1
    
    print("Node Type Distribution:")
    for node_type, count in sorted(node_types.items()):
        print(f"  {node_type}: {count}")
    print()
    
    # Save to file
    filename = "test_complex_workflow.json"
    builder.save_to_file(filename)
    print(f"✓ Workflow definition saved to: {filename}")
    print()
    
    return workflow_def


def validate_workflow_structure(workflow_def):
    """Validate workflow structure"""
    print_header("Workflow Structure Validation")
    
    workflow = workflow_def['workflow']
    nodes = workflow['nodes']
    edges = workflow['edges']
    
    errors = []
    warnings = []
    
    # Check for start node
    start_nodes = [n for n in nodes if n['node_type'] == 'start']
    if len(start_nodes) == 0:
        errors.append("No start node found")
    elif len(start_nodes) > 1:
        errors.append(f"Multiple start nodes found: {len(start_nodes)}")
    else:
        print("✓ Found exactly one start node")
    
    # Check for end node
    end_nodes = [n for n in nodes if n['node_type'] == 'end']
    if len(end_nodes) == 0:
        warnings.append("No end node found")
    else:
        print(f"✓ Found {len(end_nodes)} end node(s)")
    
    # Check for orphaned nodes
    node_ids = {n['node_id'] for n in nodes}
    connected_nodes = set()
    for edge in edges:
        connected_nodes.add(edge['source'])
        connected_nodes.add(edge['target'])
    
    orphaned = node_ids - connected_nodes
    if orphaned and orphaned != {n['node_id'] for n in start_nodes}:
        warnings.append(f"Orphaned nodes found: {orphaned}")
    else:
        print("✓ No orphaned nodes")
    
    # Check edge validity
    for edge in edges:
        if edge['source'] not in node_ids:
            errors.append(f"Edge source not found: {edge['source']}")
        if edge['target'] not in node_ids:
            errors.append(f"Edge target not found: {edge['target']}")
    
    if not errors:
        print("✓ All edges are valid")
    
    # Print results
    print()
    if errors:
        print("ERRORS:")
        for error in errors:
            print(f"  ✗ {error}")
    
    if warnings:
        print("WARNINGS:")
        for warning in warnings:
            print(f"  ⚠ {warning}")
    
    if not errors and not warnings:
        print("✓ Workflow structure is valid!")
    
    print()
    return len(errors) == 0


def test_workflow_json_export():
    """Test workflow JSON export"""
    print_header("Workflow JSON Export Test")
    
    builder = create_sequential_workflow()
    
    # Test JSON export
    json_str = builder.to_json()
    print("JSON Export (first 500 chars):")
    print(json_str[:500])
    print("...")
    print()
    
    # Test round-trip
    parsed = json.loads(json_str)
    print(f"✓ JSON parsing successful")
    print(f"✓ Workflow name: {parsed['name']}")
    print(f"✓ Node count: {len(parsed['workflow']['nodes'])}")
    print()


def compare_json_and_python_workflows():
    """Compare JSON and Python workflow definitions"""
    print_header("Comparing JSON vs Python Workflows")
    
    # Load JSON workflow
    json_file = "workflow_management/example_workflows.json"
    if os.path.exists(json_file):
        with open(json_file, 'r') as f:
            json_workflows = json.load(f)
        
        # Create Python workflow
        python_workflow = create_sequential_workflow().build()
        
        # Compare node counts
        json_seq = json_workflows.get('sequential_workflow', {})
        json_nodes = len(json_seq.get('workflow', {}).get('nodes', []))
        python_nodes = len(python_workflow.get('workflow', {}).get('nodes', []))
        
        print(f"JSON Sequential Workflow nodes: {json_nodes}")
        print(f"Python Sequential Workflow nodes: {python_nodes}")
        print()
        
        if json_nodes == python_nodes:
            print("✓ Node counts match!")
        else:
            print("⚠ Node counts differ")
        print()
    else:
        print(f"JSON file not found: {json_file}")
        print()


def generate_workflow_documentation():
    """Generate workflow documentation"""
    print_header("Generating Workflow Documentation")
    
    workflows = [
        ("Sequential", create_sequential_workflow()),
        ("Parallel", create_parallel_workflow()),
        ("HITL", create_hitl_workflow()),
        ("Complex", create_complex_workflow())
    ]
    
    doc_file = "workflow_documentation.md"
    with open(doc_file, 'w') as f:
        f.write("# Workflow Examples Documentation\n\n")
        f.write("Generated: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "\n\n")
        
        for name, builder in workflows:
            workflow_def = builder.build()
            f.write(f"## {name} Workflow\n\n")
            f.write(f"**Description:** {workflow_def['description']}\n\n")
            f.write(f"**Version:** {workflow_def['version']}\n\n")
            f.write(f"**Statistics:**\n")
            f.write(f"- Nodes: {len(workflow_def['workflow']['nodes'])}\n")
            f.write(f"- Edges: {len(workflow_def['workflow']['edges'])}\n")
            f.write(f"- Variables: {len(workflow_def['workflow']['variables'])}\n\n")
            
            f.write("**Nodes:**\n")
            for node in workflow_def['workflow']['nodes']:
                f.write(f"- `{node['node_id']}`: {node['name']} ({node['node_type']})\n")
            f.write("\n")
            
            f.write("**Flow:**\n```\n")
            for edge in workflow_def['workflow']['edges']:
                f.write(f"{edge['source']} -> {edge['target']}\n")
            f.write("```\n\n")
            f.write("---\n\n")
    
    print(f"✓ Documentation generated: {doc_file}")
    print()


def main():
    """Main test function"""
    print("\n")
    print("=" * 80)
    print("  ABHIKARTA WORKFLOW SYSTEM - WORKFLOW TESTING")
    print("=" * 80)
    print("\n")
    
    try:
        # Test workflow creation
        seq_wf = test_sequential_workflow()
        par_wf = test_parallel_workflow()
        hitl_wf = test_hitl_workflow()
        complex_wf = test_complex_workflow()
        
        # Validate workflows
        print_separator()
        print("Validating all workflows...")
        print_separator()
        
        all_valid = True
        for name, wf in [("Sequential", seq_wf), ("Parallel", par_wf), 
                         ("HITL", hitl_wf), ("Complex", complex_wf)]:
            print(f"\nValidating {name} Workflow:")
            if not validate_workflow_structure(wf):
                all_valid = False
        
        # Test JSON export
        test_workflow_json_export()
        
        # Compare implementations
        compare_json_and_python_workflows()
        
        # Generate documentation
        generate_workflow_documentation()
        
        # Final summary
        print_separator("=")
        if all_valid:
            print("  ✓ ALL WORKFLOW TESTS PASSED!")
        else:
            print("  ⚠ SOME WORKFLOWS HAVE ISSUES")
        print_separator("=")
        print()
        
        print("Generated Files:")
        for filename in ["test_sequential_workflow.json", "test_parallel_workflow.json",
                        "test_hitl_workflow.json", "test_complex_workflow.json",
                        "workflow_documentation.md"]:
            if os.path.exists(filename):
                size = os.path.getsize(filename)
                print(f"  • {filename} ({size} bytes)")
        print()
        
        return 0 if all_valid else 1
        
    except Exception as e:
        print(f"\n✗ ERROR: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
