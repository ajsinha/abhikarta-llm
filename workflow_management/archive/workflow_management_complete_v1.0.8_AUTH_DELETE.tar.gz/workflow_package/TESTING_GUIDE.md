# Workflow Management System - Testing Guide

**Copyright © 2025-2030, All Rights Reserved**  
**Ashutosh Sinha | Email: ajsinha@gmail.com**

---

## Overview

This guide covers all testing scripts and examples for the Abhikarta Workflow Management System. All tests are command-line runnable and demonstrate the complete functionality.

---

## Test Files Structure

```
workflow_package/
├── test_tools.py              # Test all example tools
├── test_workflows.py          # Test workflow definitions
├── test_integration.py        # End-to-end integration tests
├── workflow_management/
│   ├── example_tools.py       # 6 example tools extending BaseTool
│   ├── example_workflows.json # JSON workflow definitions
│   └── workflow_builders.py   # Python workflow builders
```

---

## Quick Start

### 1. Test Tools (No Database Required)

```bash
cd workflow_package
python test_tools.py
```

**What it tests:**
- All 6 example tools
- Tool schemas (Anthropic & OpenAI formats)
- Parameter validation
- Error handling
- Execution tracking

**Expected Output:**
```
==============================================================================
  ABHIKARTA WORKFLOW SYSTEM - TOOL TESTING
==============================================================================

Available Tools
==============================================================================
  • text_analysis: Analyzes text and provides word count, character count, and sentiment
  • data_transform: Transforms data by applying operations like uppercase, lowercase, or reverse
  • math_calculator: Performs basic mathematical operations
  • delay_simulator: Simulates a delay for testing purposes
  • random_number: Generates random numbers within a specified range
  • data_validator: Validates data against specified rules

Testing Text Analysis Tool
==============================================================================
Tool Name: text_analysis
Description: Analyzes text and provides word count, character count, and sentiment
Type: data_processing

Test 1: Analyzing sample text...
Success: True
Data: {
  "word_count": 9,
  "character_count": 63,
  "sentiment": "positive",
  ...
}
...
```

### 2. Test Workflow Definitions

```bash
python test_workflows.py
```

**What it tests:**
- Sequential workflow creation
- Parallel workflow creation
- HITL workflow creation
- Complex multi-pattern workflow
- Workflow validation
- JSON export/import
- Documentation generation

**Expected Output:**
```
==============================================================================
  ABHIKARTA WORKFLOW SYSTEM - WORKFLOW TESTING
==============================================================================

Sequential Workflow Test
==============================================================================
Name: Sequential Text Processing
Description: Processes text through a sequence of transformations
Version: 1.0.0
Nodes: 5
Edges: 4
Variables: 1

Nodes:
  [start] Start (start)
  [analyze_text] Analyze Text (tool)
  [transform_text] Transform to Uppercase (tool)
  [validate_length] Validate Word Count (tool)
  [end] End (end)
...
```

**Generated Files:**
- `test_sequential_workflow.json`
- `test_parallel_workflow.json`
- `test_hitl_workflow.json`
- `test_complex_workflow.json`
- `workflow_documentation.md`

### 3. Integration Test (Complete End-to-End)

```bash
python test_integration.py
```

**What it tests:**
- Actual workflow execution (without database)
- Tool integration with workflows
- Sequential execution patterns
- Parallel execution patterns
- Multiple workflow scenarios

**Expected Output:**
```
==============================================================================
  ABHIKARTA WORKFLOW SYSTEM - INTEGRATION TEST
==============================================================================

Test 1: Simple Sequential Workflow
==============================================================================

Executing Workflow: Simple Text Processing
Description: Text analysis then transformation
--------------------------------------------------------------------------------
  ► Starting workflow from: Start
  ⚙ Executing: [analyze] Analyze Text (tool)
    ✓ Result: {
          "word_count": 5,
          "character_count": 29,
          "sentiment": "neutral",
          ...
        }
  ⚙ Executing: [transform] Transform to Uppercase (tool)
    ✓ Result: {
          "input": "Hello World from Abhikarta!",
          "output": "HELLO WORLD FROM ABHIKARTA!",
          "operation": "uppercase"
        }
  → Reached end node: End
--------------------------------------------------------------------------------
✓ Workflow Execution Complete

Success: True
...
```

---

## Example Tools

All tools extend `BaseTool` and are located in `workflow_management/example_tools.py`:

### 1. TextAnalysisTool
```python
tool = TextAnalysisTool()
result = tool._execute_with_tracking(
    text="Hello World! This is great software."
)
# Returns: word_count, char_count, sentiment, etc.
```

### 2. DataTransformTool
```python
tool = DataTransformTool()
result = tool._execute_with_tracking(
    input_data="hello world",
    operation="uppercase"  # or lowercase, reverse, title
)
# Returns: transformed output
```

### 3. MathCalculatorTool
```python
tool = MathCalculatorTool()
result = tool._execute_with_tracking(
    operation="add",  # or subtract, multiply, divide, power, sqrt
    operand1=10,
    operand2=5
)
# Returns: calculation result
```

### 4. RandomNumberTool
```python
tool = RandomNumberTool()
result = tool._execute_with_tracking(
    min_value=1,
    max_value=100,
    count=5
)
# Returns: list of random numbers with statistics
```

### 5. DataValidatorTool
```python
tool = DataValidatorTool()
result = tool._execute_with_tracking(
    value=75,
    min_threshold=0,
    max_threshold=100
)
# Returns: validation result (PASS/FAIL)
```

### 6. DelaySimulatorTool
```python
tool = DelaySimulatorTool()
result = tool._execute_with_tracking(
    delay_seconds=2,
    message="Test complete"
)
# Returns: after specified delay
```

---

## Workflow Examples

### Sequential Workflow (JSON)

```json
{
  "name": "Sequential Text Processing",
  "workflow": {
    "nodes": [
      {"node_id": "start", "node_type": "start"},
      {
        "node_id": "analyze",
        "node_type": "tool",
        "config": {
          "tool_name": "text_analysis",
          "parameters": {"text": "{{input_text}}"}
        }
      },
      {"node_id": "end", "node_type": "end"}
    ],
    "edges": [
      {"source": "start", "target": "analyze"},
      {"source": "analyze", "target": "end"}
    ],
    "variables": {
      "input_text": "Sample text"
    }
  }
}
```

### Sequential Workflow (Python)

```python
from workflow_management.workflow_builders import WorkflowBuilder, WorkflowNode, WorkflowEdge

builder = WorkflowBuilder(
    name="Sequential Workflow",
    description="Processes data sequentially",
    version="1.0.0"
)

builder.add_node(WorkflowNode(
    node_id="start",
    node_type="start",
    name="Start"
))

builder.add_node(WorkflowNode(
    node_id="analyze",
    node_type="tool",
    name="Analyze Text",
    config={
        "tool_name": "text_analysis",
        "parameters": {"text": "{{input_text}}"}
    }
))

builder.add_node(WorkflowNode(
    node_id="end",
    node_type="end",
    name="End"
))

builder.add_edge(WorkflowEdge("start", "analyze"))
builder.add_edge(WorkflowEdge("analyze", "end"))

builder.set_variable("input_text", "Hello World")

# Get workflow definition
workflow_def = builder.build()

# Save to file
builder.save_to_file("my_workflow.json")
```

### Parallel Workflow (Python)

```python
builder = WorkflowBuilder(
    name="Parallel Workflow",
    description="Executes multiple branches in parallel"
)

builder.add_node(WorkflowNode(node_id="start", node_type="start", name="Start"))

builder.add_node(WorkflowNode(
    node_id="parallel_split",
    node_type="parallel",
    name="Split into Parallel Branches"
))

# Branch 1
builder.add_node(WorkflowNode(
    node_id="branch1",
    node_type="tool",
    name="Branch 1",
    config={
        "tool_name": "text_analysis",
        "parameters": {"text": "Branch 1 data"}
    }
))

# Branch 2
builder.add_node(WorkflowNode(
    node_id="branch2",
    node_type="tool",
    name="Branch 2",
    config={
        "tool_name": "random_number",
        "parameters": {"min_value": 1, "max_value": 100, "count": 5}
    }
))

builder.add_node(WorkflowNode(node_id="end", node_type="end", name="End"))

# Connect edges
builder.add_edge(WorkflowEdge("start", "parallel_split"))
builder.add_edge(WorkflowEdge("parallel_split", "branch1", priority=1))
builder.add_edge(WorkflowEdge("parallel_split", "branch2", priority=2))
builder.add_edge(WorkflowEdge("branch1", "end"))
builder.add_edge(WorkflowEdge("branch2", "end"))
```

### HITL Workflow (Python)

```python
builder = WorkflowBuilder(
    name="HITL Workflow",
    description="Requires human approval"
)

builder.add_node(WorkflowNode(node_id="start", node_type="start", name="Start"))

# Generate data
builder.add_node(WorkflowNode(
    node_id="generate",
    node_type="tool",
    name="Generate Data",
    config={
        "tool_name": "random_number",
        "parameters": {"min_value": 1, "max_value": 100, "count": 10}
    }
))

# Human approval
builder.add_node(WorkflowNode(
    node_id="human_approval",
    node_type="human",
    name="Request Approval",
    config={
        "assigned_to": "admin",
        "task_type": "approval",
        "timeout": 3600,
        "instructions": "Please review and approve"
    }
))

# Conditional check
builder.add_node(WorkflowNode(
    node_id="check",
    node_type="conditional",
    name="Check Approval",
    config={"condition": "status == 'completed'"}
))

# Approved path
builder.add_node(WorkflowNode(
    node_id="approved",
    node_type="tool",
    name="Process Approved",
    config={
        "tool_name": "data_transform",
        "parameters": {
            "input_data": "Approved",
            "operation": "uppercase"
        }
    }
))

# Rejected path
builder.add_node(WorkflowNode(
    node_id="rejected",
    node_type="tool",
    name="Handle Rejection",
    config={
        "tool_name": "data_transform",
        "parameters": {
            "input_data": "Rejected",
            "operation": "uppercase"
        }
    }
))

builder.add_node(WorkflowNode(node_id="end_approved", node_type="end", name="End (Approved)"))
builder.add_node(WorkflowNode(node_id="end_rejected", node_type="end", name="End (Rejected)"))

# Connect edges
builder.add_edge(WorkflowEdge("start", "generate"))
builder.add_edge(WorkflowEdge("generate", "human_approval"))
builder.add_edge(WorkflowEdge("human_approval", "check"))
builder.add_edge(WorkflowEdge("check", "approved", condition="status == 'completed'"))
builder.add_edge(WorkflowEdge("check", "rejected", condition="status == 'rejected'"))
builder.add_edge(WorkflowEdge("approved", "end_approved"))
builder.add_edge(WorkflowEdge("rejected", "end_rejected"))
```

---

## Running Individual Tools

You can run individual tools from Python:

```python
from workflow_management.example_tools import get_tool

# Get a tool
tool = get_tool("text_analysis")

# Execute with parameters
result = tool._execute_with_tracking(
    text="This is a test message with great content!"
)

# Check result
if result.success:
    print(f"Success! Data: {result.data}")
    print(f"Execution time: {result.execution_time}s")
else:
    print(f"Failed: {result.error}")

# Get tool schema for LLM
schema = tool.get_anthropic_schema()
print(json.dumps(schema, indent=2))
```

---

## Testing Checklist

Before deployment, run through this checklist:

### Tool Tests
- [ ] All 6 tools execute successfully
- [ ] Parameter validation works
- [ ] Error handling is correct
- [ ] Schemas generate properly
- [ ] Execution tracking functions

### Workflow Tests
- [ ] Sequential workflow creates correctly
- [ ] Parallel workflow validates
- [ ] HITL workflow structure is valid
- [ ] JSON export/import works
- [ ] Python builders generate valid JSON

### Integration Tests
- [ ] Sequential workflows execute
- [ ] Parallel branches run
- [ ] Tools integrate with workflows
- [ ] Variables resolve correctly
- [ ] Error handling works end-to-end

---

## Troubleshooting

### Import Errors

If you get import errors:
```bash
# Make sure you're in the workflow_package directory
cd /path/to/workflow_package

# Run with Python module syntax
python -m test_tools
python -m test_workflows
python -m test_integration
```

### Tool Not Found

If tools aren't found:
```python
# Check available tools
from workflow_management.example_tools import list_available_tools
print(list_available_tools())
```

### Workflow Validation Fails

Common issues:
- Missing start node
- No end node
- Invalid edge references
- Circular dependencies

Use the validation in test_workflows.py to check.

---

## Performance Benchmarks

Expected performance on standard hardware:

| Test | Duration | Throughput |
|------|----------|------------|
| Tool Tests | < 5 seconds | ~10 tools/sec |
| Workflow Tests | < 3 seconds | ~4 workflows/sec |
| Integration Tests | < 10 seconds | ~2 workflows/sec |

---

## Next Steps

1. Run all test scripts to verify installation
2. Review generated workflow JSON files
3. Examine workflow documentation
4. Create custom tools extending BaseTool
5. Build custom workflows using Python builders
6. Deploy to production with database integration

---

## Support

For issues or questions:
- Email: ajsinha@gmail.com
- Review test output for detailed error messages
- Check generated JSON files for structure
- Examine execution logs for debugging

---

**Version:** 1.0.0  
**Last Updated:** November 22, 2025
