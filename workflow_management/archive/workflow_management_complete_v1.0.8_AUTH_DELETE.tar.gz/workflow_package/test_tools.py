#!/usr/bin/env python3
"""
Test Script for Example Tools

Copyright © 2025-2030, All Rights Reserved
Ashutosh Sinha | Email: ajsinha@gmail.com

This script tests all example tools from the command line.
"""

import sys
import json
from workflow_management.example_tools import (
    TextAnalysisTool,
    DataTransformTool,
    MathCalculatorTool,
    DelaySimulatorTool,
    RandomNumberTool,
    DataValidatorTool,
    list_available_tools
)


def print_separator(char="=", length=80):
    """Print a separator line"""
    print(char * length)


def print_header(title):
    """Print a section header"""
    print_separator()
    print(f"  {title}")
    print_separator()


def test_text_analysis():
    """Test TextAnalysisTool"""
    print_header("Testing Text Analysis Tool")
    
    tool = TextAnalysisTool()
    print(f"Tool Name: {tool.name}")
    print(f"Description: {tool.description}")
    print(f"Type: {tool.tool_type.value}")
    print()
    
    # Test 1: Basic analysis
    print("Test 1: Analyzing sample text...")
    result = tool._execute_with_tracking(
        text="This is a great test! I love testing software. It's excellent."
    )
    print(f"Success: {result.success}")
    print(f"Data: {json.dumps(result.data, indent=2)}")
    print(f"Execution Time: {result.execution_time:.4f}s")
    print()
    
    # Test 2: Negative sentiment
    print("Test 2: Analyzing negative text...")
    result = tool._execute_with_tracking(
        text="This is terrible and awful. I hate bad software."
    )
    print(f"Sentiment: {result.data['sentiment']}")
    print()


def test_data_transform():
    """Test DataTransformTool"""
    print_header("Testing Data Transform Tool")
    
    tool = DataTransformTool()
    test_text = "Hello World"
    
    operations = ["uppercase", "lowercase", "reverse", "title"]
    for op in operations:
        print(f"Testing {op} operation...")
        result = tool._execute_with_tracking(
            input_data=test_text,
            operation=op
        )
        print(f"  Input: {test_text}")
        print(f"  Output: {result.data['output']}")
        print()


def test_math_calculator():
    """Test MathCalculatorTool"""
    print_header("Testing Math Calculator Tool")
    
    tool = MathCalculatorTool()
    
    test_cases = [
        ("add", 10, 5),
        ("subtract", 10, 5),
        ("multiply", 10, 5),
        ("divide", 10, 5),
        ("power", 2, 3),
        ("sqrt", 16, 0)
    ]
    
    for operation, op1, op2 in test_cases:
        print(f"Testing {operation}: {op1}, {op2}")
        result = tool._execute_with_tracking(
            operation=operation,
            operand1=op1,
            operand2=op2
        )
        if result.success:
            print(f"  Result: {result.data['result']}")
        else:
            print(f"  Error: {result.error}")
        print()


def test_random_number():
    """Test RandomNumberTool"""
    print_header("Testing Random Number Tool")
    
    tool = RandomNumberTool()
    
    print("Generating 5 random numbers between 1 and 100...")
    result = tool._execute_with_tracking(
        min_value=1,
        max_value=100,
        count=5
    )
    
    if result.success:
        print(f"Numbers: {result.data['numbers']}")
        print(f"Sum: {result.data['sum']}")
        print(f"Average: {result.data['average']:.2f}")
    print()


def test_data_validator():
    """Test DataValidatorTool"""
    print_header("Testing Data Validator Tool")
    
    tool = DataValidatorTool()
    
    test_cases = [
        (50, 0, 100, "Should PASS"),
        (150, 0, 100, "Should FAIL (too high)"),
        (-10, 0, 100, "Should FAIL (too low)")
    ]
    
    for value, min_th, max_th, expected in test_cases:
        print(f"Testing: value={value}, range=[{min_th}, {max_th}] - {expected}")
        result = tool._execute_with_tracking(
            value=value,
            min_threshold=min_th,
            max_threshold=max_th
        )
        if result.success:
            print(f"  Valid: {result.data['is_valid']}")
            print(f"  Result: {result.data['validation_result']}")
            if 'reason' in result.data:
                print(f"  Reason: {result.data['reason']}")
        print()


def test_delay_simulator():
    """Test DelaySimulatorTool"""
    print_header("Testing Delay Simulator Tool")
    
    tool = DelaySimulatorTool()
    
    print("Simulating 2-second delay...")
    result = tool._execute_with_tracking(
        delay_seconds=2,
        message="Test delay completed!"
    )
    
    if result.success:
        print(f"Message: {result.data['message']}")
        print(f"Execution time: {result.execution_time:.4f}s")
    print()


def test_tool_schemas():
    """Test tool schema generation"""
    print_header("Testing Tool Schema Generation")
    
    tool = TextAnalysisTool()
    
    print("1. Standard Schema:")
    print(json.dumps(tool.get_schema(), indent=2))
    print()
    
    print("2. Anthropic Schema:")
    print(json.dumps(tool.get_anthropic_schema(), indent=2))
    print()
    
    print("3. OpenAI Schema:")
    print(json.dumps(tool.get_openai_schema(), indent=2))
    print()


def test_error_handling():
    """Test error handling"""
    print_header("Testing Error Handling")
    
    # Test 1: Invalid parameter
    print("Test 1: Invalid parameter type...")
    tool = MathCalculatorTool()
    result = tool._execute_with_tracking(
        operation="invalid_op",
        operand1=10,
        operand2=5
    )
    print(f"Success: {result.success}")
    print(f"Error: {result.error}")
    print()
    
    # Test 2: Division by zero
    print("Test 2: Division by zero...")
    result = tool._execute_with_tracking(
        operation="divide",
        operand1=10,
        operand2=0
    )
    print(f"Success: {result.success}")
    print(f"Error: {result.error}")
    print()
    
    # Test 3: Missing required parameter
    print("Test 3: Missing required parameter...")
    text_tool = TextAnalysisTool()
    result = text_tool._execute_with_tracking()
    print(f"Success: {result.success}")
    print(f"Error Type: {result.error_type}")
    print(f"Error: {result.error}")
    print()


def list_tools():
    """List all available tools"""
    print_header("Available Tools")
    tools = list_available_tools()
    for name, description in tools.items():
        print(f"  • {name}: {description}")
    print()


def main():
    """Main test function"""
    print("\n")
    print("=" * 80)
    print("  ABHIKARTA WORKFLOW SYSTEM - TOOL TESTING")
    print("=" * 80)
    print("\n")
    
    # List available tools
    list_tools()
    
    # Run all tests
    try:
        test_text_analysis()
        test_data_transform()
        test_math_calculator()
        test_random_number()
        test_data_validator()
        test_delay_simulator()
        test_tool_schemas()
        test_error_handling()
        
        print_separator("=")
        print("  ✓ ALL TESTS COMPLETED SUCCESSFULLY!")
        print_separator("=")
        print()
        
        return 0
        
    except Exception as e:
        print(f"\n✗ ERROR: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
