# Workflow Management Module - Installation Guide

**Copyright © 2025-2030, All Rights Reserved**  
**Ashutosh Sinha | Email: ajsinha@gmail.com**

---

## Prerequisites

Before installing the Workflow Management Module, ensure you have:

1. **Abhikarta LLM Platform** - Installed and running
2. **Database** - SQLite, MySQL, or PostgreSQL
3. **Python 3.8+** - With required dependencies
4. **Database Access** - Permissions to create tables and indexes

## Step 1: Database Schema Installation

### For SQLite

```bash
# Navigate to the workflow_management directory
cd /path/to/workflow_management

# Create or open your database
sqlite3 /path/to/abhikarta.db < db_schemas/sqlite_schema.sql

# Verify tables were created
sqlite3 /path/to/abhikarta.db "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'wf_%';"
```

Expected output should list 6 tables:
- wf_workflows
- wf_executions
- wf_node_executions
- wf_human_tasks
- wf_variables
- wf_audit_logs

### For MySQL

```bash
# Connect to MySQL and create database (if needed)
mysql -u root -p
CREATE DATABASE IF NOT EXISTS abhikarta;
EXIT;

# Run the schema
mysql -u root -p abhikarta < db_schemas/mysql_schema.sql

# Verify tables
mysql -u root -p abhikarta -e "SHOW TABLES LIKE 'wf_%';"
```

### For PostgreSQL

```bash
# Connect and create database (if needed)
psql -U postgres
CREATE DATABASE abhikarta;
\q

# Run the schema
psql -U postgres -d abhikarta -f db_schemas/postgresql_schema.sql

# Verify tables
psql -U postgres -d abhikarta -c "SELECT tablename FROM pg_tables WHERE tablename LIKE 'wf_%';"
```

## Step 2: Copy Module to Abhikarta

Copy the entire `workflow_management` directory to your Abhikarta installation:

```bash
# From the workflow_package directory
cp -r workflow_management /path/to/abhikarta/

# Verify the structure
ls -la /path/to/abhikarta/workflow_management/
```

Expected directory structure:
```
workflow_management/
├── __init__.py
├── workflow_db_handler.py
├── workflow_execution_engine.py
├── workflow_routes.py
├── models/
│   ├── __init__.py
│   └── workflow_models.py
├── db_schemas/
│   ├── sqlite_schema.sql
│   ├── mysql_schema.sql
│   └── postgresql_schema.sql
└── templates/
    └── workflow/
        ├── dashboard.html
        ├── list.html
        ├── create.html
        ├── execution_detail.html
        └── tasks.html
```

## Step 3: Update Abhikarta Web Application

### 3.1 Register Workflow Routes

Edit `/path/to/abhikarta/abhikarta_llm_web.py`:

Find the `_register_routes` method and add the WorkflowRoutes import and registration:

```python
# Add this import at the top of the file
from workflow_management.workflow_routes import WorkflowRoutes

# In the _register_routes method, find the list of route classes:
for rt in [AuthRoutes, AdminRoutes, ResourceRoutes, RoleRoutes, 
           UserRoutes, ModelRoutes, MCPRoutes, LLMRoutes, WorkflowRoutes]:  # Added WorkflowRoutes
    logger.info(f'registering route using {rt}')
    r_rt = rt(self.app, self.db_connection_pool_name)
    check_and_run_a_method(r_rt, 'set_facade_cache', self.facade_cache)
    self._prepare_a_route(r_rt)
```

### 3.2 Update Navigation Menu

The workflow routes will automatically appear in the navigation. The existing "Run" dropdown menu in `base.html` already includes workflow (marked as "Coming Soon"). The routes will make it functional.

If you want to update the menu, edit `/path/to/abhikarta/templates/base.html`:

Find the "Run" dropdown and update:

```html
<li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="runDropdown" role="button"
       data-bs-toggle="dropdown" aria-expanded="false">
        <i class="fas fa-play-circle"></i> Run
    </a>
    <ul class="dropdown-menu" aria-labelledby="runDropdown">
        <li><a class="dropdown-item" href="{{ url_for('llm_chat') }}">
            <i class="fas fa-comments"></i> Chat
        </a></li>
        <li><hr class="dropdown-divider"></li>
        <!-- Remove 'disabled' class to enable workflow menu -->
        <li><a class="dropdown-item" href="{{ url_for('workflow_dashboard') }}">
            <i class="fas fa-project-diagram"></i> Workflow
        </a></li>
        <li><a class="dropdown-item disabled" href="#">
            <i class="fas fa-robot"></i> Agent (Coming Soon)
        </a></li>
    </ul>
</li>
```

## Step 4: Verify Installation

### 4.1 Start Abhikarta

```bash
cd /path/to/abhikarta
python main.py  # or your startup script
```

### 4.2 Test Database Connection

Create a test script `test_workflow_db.py`:

```python
from workflow_management.workflow_db_handler import WorkflowDBHandler

# Use your actual database connection pool name
db_handler = WorkflowDBHandler('your_pool_name')

# Test listing workflows
workflows = db_handler.list_workflows()
print(f"Database connection successful! Found {len(workflows)} workflows.")
```

Run the test:
```bash
python test_workflow_db.py
```

### 4.3 Test Web Interface

1. Open your browser and navigate to: `http://localhost:5000/workflow/dashboard`
2. You should see the Workflow Dashboard
3. Try creating a simple workflow using the template

## Step 5: Create Your First Workflow

1. Navigate to **Workflow Dashboard**
2. Click **Create Workflow**
3. Enter:
   - Name: "Test Workflow"
   - Description: "My first workflow"
   - Version: "1.0.0"
4. Click **Load Sample Template**
5. Click **Create Workflow**
6. Execute the workflow from the list
7. Monitor execution in real-time

## Troubleshooting

### Issue: "Table 'wf_workflows' doesn't exist"

**Solution:**
```bash
# Verify database schema was installed correctly
# For SQLite:
sqlite3 /path/to/abhikarta.db ".tables"

# For MySQL:
mysql -u root -p abhikarta -e "SHOW TABLES;"

# If tables are missing, re-run the schema installation (Step 1)
```

### Issue: "Module 'workflow_management' not found"

**Solution:**
```bash
# Ensure the directory is in the correct location
ls -la /path/to/abhikarta/workflow_management/

# Check Python path
python -c "import sys; print('\n'.join(sys.path))"

# Ensure abhikarta directory is in Python path
```

### Issue: Routes not registered

**Solution:**
1. Check that WorkflowRoutes is imported in `abhikarta_llm_web.py`
2. Verify it's added to the routes list in `_register_routes`
3. Check Flask logs for any registration errors
4. Restart the application

### Issue: Templates not found

**Solution:**
```bash
# Verify templates directory structure
ls -la /path/to/abhikarta/workflow_management/templates/workflow/

# Ensure all required templates exist:
# - dashboard.html
# - list.html
# - create.html
# - execution_detail.html
# - tasks.html
```

### Issue: Database connection errors

**Solution:**
1. Verify your database connection pool configuration
2. Check database credentials
3. Ensure database server is running
4. Test connection with database client

## Configuration Options

### Thread Pool Size

To change the number of worker threads for parallel execution, modify in your code:

```python
from workflow_management.workflow_execution_engine import WorkflowExecutionEngine

# Default is 10 workers
engine = WorkflowExecutionEngine(db_handler, max_workers=20)
```

### Execution Timeouts

Configure node-level timeouts in workflow definition:

```json
{
  "node_id": "llm_1",
  "node_type": "llm",
  "timeout": 300,  // seconds
  "retry_count": 3,
  "retry_backoff": "exponential"
}
```

## Security Considerations

### Database Permissions

Ensure the database user has appropriate permissions:

```sql
-- For MySQL
GRANT SELECT, INSERT, UPDATE, DELETE ON abhikarta.wf_* TO 'abhikarta_user'@'localhost';

-- For PostgreSQL
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO abhikarta_user;
```

### File Permissions

Set appropriate permissions on the workflow_management directory:

```bash
chmod -R 755 /path/to/abhikarta/workflow_management/
chown -R your_user:your_group /path/to/abhikarta/workflow_management/
```

## Performance Optimization

### Database Indexing

Indexes are automatically created by the schema. To verify:

```sql
-- For MySQL
SHOW INDEX FROM wf_executions;

-- For PostgreSQL
SELECT indexname FROM pg_indexes WHERE tablename = 'wf_executions';
```

### Connection Pooling

Use the existing Abhikarta connection pool manager. Recommended settings:

```python
pool_config = {
    'pool_size': 10,
    'max_overflow': 20,
    'pool_timeout': 30,
    'pool_recycle': 3600
}
```

## Next Steps

1. Read the main README.md for usage instructions
2. Review the sample workflow definitions
3. Explore the UI features
4. Set up monitoring and alerts
5. Configure backup procedures for workflow data

## Support

For installation issues:
- Email: ajsinha@gmail.com
- Check logs in `/path/to/abhikarta/logs/`
- Review database error logs
- Verify all prerequisites are met

---

**Installation Guide Version:** 1.0.0  
**Last Updated:** November 22, 2025
